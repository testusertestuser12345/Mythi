#!/usr/bin/env python3
"""target.py — 検証用ターゲット（Python 版 / 標準の argparse を使用）

使い方: target.py [-n 名前] [-c 回数] [-u] [-t タグ]... ファイル...
  -n, --name 名前    名前（省略時 World）
  -c, --count 回数   1〜10（省略時 1）
  -u, --upper        大文字にする
  -t, --tag タグ     タグ（何回でも指定できる）
  ファイル           1つ以上必要

このスクリプトがやること
  1. 受け取った引数を、1個ずつ ‹ › で囲んでそのまま表示する
  2. オプションを解釈した結果を表示する
  3. 成功なら終了コード 0、エラーなら終了コード 2 で終わる
"""
import argparse
import re
import sys

print("===== target.py（Python / argparse）=====")

# ---- 1. 受け取った引数をそのまま表示 ----
args = sys.argv[1:]
print(f"受け取った引数: {len(args)} 個")
for i, a in enumerate(args, 1):
    print(f"  [{i}] ‹{a}›")


# エラーのときに呼ぶ
def error(message):
    print(f"結果: エラー（終了コード 2）: {message}")
    print(f"target.py: error: {message}", file=sys.stderr)
    sys.exit(2)


# argparse 自身のエラーも、上の error() で表示する
class Parser(argparse.ArgumentParser):
    def error(self, message):
        error(message)


# ---- 2. オプションを解釈 ----
p = Parser(prog="target.py")
p.add_argument("-n", "--name", default="World")
p.add_argument("-c", "--count", default="1")
p.add_argument("-u", "--upper", action="store_true")
p.add_argument("-t", "--tag", dest="tags", action="append", default=[])
p.add_argument("files", nargs="*")
o = p.parse_args()

# ---- 値のチェック ----
if not re.fullmatch(r"[1-9]|10", o.count):
    error(f"回数は 1〜10 で指定してください（指定値: ‹{o.count}›）")
if not o.files:
    error("ファイルを1つ以上指定してください")

# ---- 3. 解釈した結果を表示 ----
print("解釈した結果:")
print(f"  名前     = ‹{o.name}›")
print(f"  回数     = {o.count}")
print(f"  大文字   = {'はい' if o.upper else 'いいえ'}")
print(f"  タグ     = {len(o.tags)} 個 " + "".join(f"‹{t}› " for t in o.tags))
print(f"  ファイル = {len(o.files)} 個 " + "".join(f"‹{f}› " for f in o.files))

msg = f"Hello, {o.name}!"
if o.upper:
    msg = msg.translate(str.maketrans("abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
for n in range(1, int(o.count) + 1):
    print(f"  {n}: {msg}")
print("結果: OK（終了コード 0）")
