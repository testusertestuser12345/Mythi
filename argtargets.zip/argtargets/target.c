/* target.c — 検証用ターゲット（バイナリ版 / C の getopt_long を使用）
 *
 * ビルド: gcc -O2 -o target_bin target.c
 * 使い方: target_bin [-n 名前] [-c 回数] [-u] [-t タグ]... ファイル...
 *   -n, --name 名前    名前（省略時 World）
 *   -c, --count 回数   1〜10（省略時 1）
 *   -u, --upper        大文字にする
 *   -t, --tag タグ     タグ（何回でも指定できる）
 *   ファイル           1つ以上必要
 *
 * このプログラムがやること
 *   1. 受け取った引数を、1個ずつ ‹ › で囲んでそのまま表示する
 *   2. オプションを解釈した結果を表示する
 *   3. 成功なら終了コード 0、エラーなら終了コード 2 で終わる
 */
#include <getopt.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* エラーのときに呼ぶ（printf と同じ書き方でメッセージを作る） */
static void error(const char *fmt, ...) {
    char message[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(message, sizeof message, fmt, ap);
    va_end(ap);
    printf("結果: エラー（終了コード 2）: %s\n", message);
    fprintf(stderr, "target_bin: error: %s\n", message);
    exit(2);
}

int main(int argc, char **argv) {
    printf("===== target_bin（バイナリ / getopt_long）=====\n");

    /* ---- 1. 受け取った引数をそのまま表示 ---- */
    printf("受け取った引数: %d 個\n", argc - 1);
    for (int i = 1; i < argc; i++) printf("  [%d] ‹%s›\n", i, argv[i]);
    fflush(stdout);

    /* ---- 2. オプションを解釈 ---- */
    const char *name = "World", *count = "1";
    int upper = 0, ntags = 0;
    const char *tags[100];

    static struct option longopts[] = {
        {"name",  required_argument, 0, 'n'},
        {"count", required_argument, 0, 'c'},
        {"upper", no_argument,       0, 'u'},
        {"tag",   required_argument, 0, 't'},
        {"help",  no_argument,       0, 'h'},
        {0, 0, 0, 0}
    };
    opterr = 0;   /* getopt 自身のエラー表示は止めて、下で日本語で出す */
    int opt;
    while ((opt = getopt_long(argc, argv, ":n:c:ut:h", longopts, NULL)) != -1) {
        switch (opt) {
        case 'n': name = optarg; break;
        case 'c': count = optarg; break;
        case 'u': upper = 1; break;
        case 't': if (ntags < 100) tags[ntags++] = optarg; break;
        case 'h': printf("使い方: target_bin [-n 名前] [-c 回数] [-u] [-t タグ]... ファイル...\n"); return 0;
        case ':': error("%s には値が必要です", argv[optind - 1]); break;
        default:  error("%s は知らないオプションです", argv[optind - 1]); break;
        }
    }
    /* getopt_long はオプションを前に並べ替えるので、optind 以降が全部ファイル */
    int nfiles = argc - optind;

    /* ---- 値のチェック ---- */
    int c = atoi(count);
    char buf[8];
    snprintf(buf, sizeof buf, "%d", c);
    if (c < 1 || c > 10 || strcmp(buf, count) != 0)
        error("回数は 1〜10 で指定してください（指定値: ‹%s›）", count);
    if (nfiles == 0) error("ファイルを1つ以上指定してください");

    /* ---- 3. 解釈した結果を表示 ---- */
    printf("解釈した結果:\n");
    printf("  名前     = ‹%s›\n", name);
    printf("  回数     = %d\n", c);
    printf("  大文字   = %s\n", upper ? "はい" : "いいえ");
    printf("  タグ     = %d 個 ", ntags);
    for (int i = 0; i < ntags; i++) printf("‹%s› ", tags[i]);
    printf("\n  ファイル = %d 個 ", nfiles);
    for (int i = optind; i < argc; i++) printf("‹%s› ", argv[i]);
    printf("\n");

    char msg[512];
    snprintf(msg, sizeof msg, "Hello, %s!", name);
    if (upper) for (char *p = msg; *p; p++) if (*p >= 'a' && *p <= 'z') *p -= 32;
    for (int n = 1; n <= c; n++) printf("  %d: %s\n", n, msg);
    printf("結果: OK（終了コード 0）\n");
    return 0;
}
