#!/usr/bin/env bash
# compare.sh — 同じ引数で 3つのターゲットを順に実行して見比べる
#
# 使い方: ./compare.sh -n "Taro Yamada" -c 2 x.txt
#   最後に、3つの終了コードを1行にまとめて表示する
cd "$(dirname "$0")" || exit 1
[ -x ./target_bin ] || gcc -O2 -o target_bin target.c || exit 1

codes=""
for t in ./target.sh ./target.py ./target_bin; do
  "$t" "$@" 2>/dev/null      # 引数は "$@" でそのまま渡す
  rc=$?                      # 終了コードはすぐ変数に取っておく
  codes="$codes  $(basename "$t")=$rc"
  echo
done
echo "終了コードまとめ:$codes"
