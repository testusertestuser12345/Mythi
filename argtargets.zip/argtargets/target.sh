#!/usr/bin/env bash
# target.sh — 検証用ターゲット（シェル版 / bash の getopts を使用）
#
# 使い方: target.sh [-n 名前] [-c 回数] [-u] [-t タグ]... ファイル...
#   -n 名前   名前（省略時 World）
#   -c 回数   1〜10（省略時 1）
#   -u        大文字にする
#   -t タグ   タグ（何回でも指定できる）
#   ファイル  1つ以上必要
#
# このスクリプトがやること
#   1. 受け取った引数を、1個ずつ ‹ › で囲んでそのまま表示する
#   2. オプションを解釈した結果を表示する
#   3. 成功なら終了コード 0、エラーなら終了コード 2 で終わる

echo "===== target.sh（シェル / getopts）====="

# ---- 1. 受け取った引数をそのまま表示 ----
echo "受け取った引数: $# 個"
i=0
for a in "$@"; do
  i=$((i + 1))
  printf '  [%d] ‹%s›\n' "$i" "$a"
done

# エラーのときに呼ぶ
error() {
  echo "結果: エラー（終了コード 2）: $1"
  echo "target.sh: error: $1" >&2
  exit 2
}

# ---- 2. オプションを解釈 ----
name="World"
count="1"
upper="いいえ"
tags=()

while getopts ":n:c:ut:h" opt; do
  case "$opt" in
    n) name="$OPTARG" ;;
    c) count="$OPTARG" ;;
    u) upper="はい" ;;
    t) tags+=("$OPTARG") ;;
    h) echo "使い方: target.sh [-n 名前] [-c 回数] [-u] [-t タグ]... ファイル..."; exit 0 ;;
    :) error "-$OPTARG には値が必要です" ;;
    \?) error "-$OPTARG は知らないオプションです" ;;
  esac
done
shift $((OPTIND - 1))   # 解釈し終わったオプションを捨てる。残りがファイル
files=("$@")

# ---- 値のチェック ----
[[ "$count" =~ ^([1-9]|10)$ ]] || error "回数は 1〜10 で指定してください（指定値: ‹$count›）"
[ ${#files[@]} -gt 0 ] || error "ファイルを1つ以上指定してください"

# ---- 3. 解釈した結果を表示 ----
echo "解釈した結果:"
echo "  名前     = ‹$name›"
echo "  回数     = $count"
echo "  大文字   = $upper"
printf '  タグ     = %d 個 ' "${#tags[@]}";  for t in "${tags[@]}";  do printf '‹%s› ' "$t"; done; echo
printf '  ファイル = %d 個 ' "${#files[@]}"; for f in "${files[@]}"; do printf '‹%s› ' "$f"; done; echo

msg="Hello, $name!"
[ "$upper" = "はい" ] && msg=$(printf '%s' "$msg" | LC_ALL=C tr a-z A-Z)
for ((n = 1; n <= count; n++)); do echo "  $n: $msg"; done
echo "結果: OK（終了コード 0）"
